from flask import Flask, request
import requests
import json
import os
import dialogflow_v2 as dialogflow

app = Flask(__name__)

TELEGRAM_TOKEN = 'TU_TOKEN_TELEGRAM'
PROJECT_ID = 'NOMBRE_PROYECTO_DIALOGFLOW'

def detect_intent_text(text, session_id):
    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(PROJECT_ID, session_id)

    text_input = dialogflow.types.TextInput(text=text, language_code='es')
    query_input = dialogflow.types.QueryInput(text=text_input)

    response = session_client.detect_intent(
        request={"session": session, "query_input": query_input}
    )
    return response.query_result.fulfillment_text

@app.route(f"/{TELEGRAM_TOKEN}", methods=["POST"])
def telegram_webhook():
    data = request.get_json()
    message = data["message"]["text"]
    chat_id = data["message"]["chat"]["id"]

    response_text = detect_intent_text(message, str(chat_id))

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": response_text
    }
    requests.post(url, json=payload)

    return "ok"

@app.route("/")
def home():
    return "Bot activo"

if __name__ == "__main__":
    app.run()